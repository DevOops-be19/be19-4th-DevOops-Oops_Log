package com.devoops.oopslog.likes.query.service;

public interface LikesQueryService {
    int oopsLikesCount(int oopsId);

    int oohLikesCount(int oohId);
}
