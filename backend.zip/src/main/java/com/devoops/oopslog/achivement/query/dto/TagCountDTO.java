package com.devoops.oopslog.achivement.query.dto;

import lombok.Data;

@Data
public class TagCountDTO {
    private String tag_name;
    private Integer tag_count;
}
