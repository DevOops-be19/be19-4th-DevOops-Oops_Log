package com.devoops.oopslog.achivement.query.dto;

import lombok.Data;

@Data
public class OopsRecordCountDTO {
    private Integer day;
    private Integer oops_count;
}
