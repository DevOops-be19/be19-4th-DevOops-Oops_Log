package com.devoops.oopslog.achivement.query.dto;

import lombok.Data;

@Data
public class OohRecordCountDTO {
    private Integer day;
    private Integer ooh_count;
}
