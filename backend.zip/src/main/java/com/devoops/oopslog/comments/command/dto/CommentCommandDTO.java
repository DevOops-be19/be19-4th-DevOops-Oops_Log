package com.devoops.oopslog.comments.command.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CommentCommandDTO {
    private String content;
}
