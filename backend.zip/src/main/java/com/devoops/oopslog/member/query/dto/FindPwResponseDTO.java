package com.devoops.oopslog.member.query.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class FindPwResponseDTO {
    private String email;
}
