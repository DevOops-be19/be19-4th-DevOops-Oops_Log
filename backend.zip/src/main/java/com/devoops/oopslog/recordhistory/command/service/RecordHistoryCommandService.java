package com.devoops.oopslog.recordhistory.command.service;

public interface RecordHistoryCommandService {
}
