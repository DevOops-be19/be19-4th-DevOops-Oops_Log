package com.devoops.oopslog.admin.query.dto;

import lombok.Data;

@Data
public class AllTagDTO {
    private Long id;
    private String tag_name;
    private String tag_type;
}
